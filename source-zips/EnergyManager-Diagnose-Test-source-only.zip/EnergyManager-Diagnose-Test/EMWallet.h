#ifndef EM_TEST_WALLET_H
#define EM_TEST_WALLET_H

#include <stdint.h>

// This structure is intentionally independent of the real game, StoreKit,
// WKWebView, network services, and account data.
typedef struct {
    int64_t money;
    int64_t stars;
    uint32_t testPurchases;
    int infiniteMoney;
    int infiniteStars;
    int freeShopping;
} EMTestWallet;

void EMWalletReset(EMTestWallet *wallet);
int64_t EMWalletVisibleMoney(const EMTestWallet *wallet);
int64_t EMWalletVisibleStars(const EMTestWallet *wallet);
int EMWalletPurchaseTestItem(EMTestWallet *wallet, int64_t price);
int EMWalletSpendTestStars(EMTestWallet *wallet, int64_t price);

#endif
