#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "../EMWallet.h"

int main(void) {
    EMTestWallet wallet;
    EMWalletReset(&wallet);
    assert(wallet.money == 1000);
    assert(wallet.stars == 50);
    assert(EMWalletPurchaseTestItem(&wallet, 200) == 1);
    assert(wallet.money == 800 && wallet.testPurchases == 1);
    assert(EMWalletPurchaseTestItem(&wallet, 1000) == 0);
    assert(EMWalletPurchaseTestItem(&wallet, -1) == 0);
    wallet.freeShopping = 1;
    assert(EMWalletPurchaseTestItem(&wallet, 400) == 1);
    assert(wallet.money == 800);
    wallet.freeShopping = 0;
    wallet.infiniteMoney = 1;
    assert(EMWalletVisibleMoney(&wallet) == 999999);
    assert(EMWalletPurchaseTestItem(&wallet, 9000000) == 1);
    assert(wallet.money == 800);
    wallet.infiniteStars = 1;
    assert(EMWalletVisibleStars(&wallet) == 999999);
    assert(EMWalletSpendTestStars(&wallet, 9000000) == 1);
    assert(wallet.stars == 50);
    EMWalletReset(&wallet);
    assert(EMWalletVisibleMoney(&wallet) == 1000 && wallet.testPurchases == 0);
    puts("Wallet-Tests OK (nur simulierte Werte)");
    return 0;
}
