#include "EMWallet.h"

void EMWalletReset(EMTestWallet *wallet) {
    if (wallet == 0) return;
    wallet->money = 1000;
    wallet->stars = 50;
    wallet->testPurchases = 0;
    wallet->infiniteMoney = 0;
    wallet->infiniteStars = 0;
    wallet->freeShopping = 0;
}

int64_t EMWalletVisibleMoney(const EMTestWallet *wallet) {
    if (wallet == 0) return 0;
    return wallet->infiniteMoney ? 999999 : wallet->money;
}

int64_t EMWalletVisibleStars(const EMTestWallet *wallet) {
    if (wallet == 0) return 0;
    return wallet->infiniteStars ? 999999 : wallet->stars;
}

int EMWalletPurchaseTestItem(EMTestWallet *wallet, int64_t price) {
    if (wallet == 0 || price < 0) return 0;
    if (!wallet->freeShopping && !wallet->infiniteMoney) {
        if (wallet->money < price) return 0;
        wallet->money -= price;
    }
    wallet->testPurchases++;
    return 1;
}

int EMWalletSpendTestStars(EMTestWallet *wallet, int64_t price) {
    if (wallet == 0 || price < 0) return 0;
    if (!wallet->infiniteStars) {
        if (wallet->stars < price) return 0;
        wallet->stars -= price;
    }
    return 1;
}
