#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <dispatch/dispatch.h>
#import "EMWallet.h"

// READ-ONLY APP DIAGNOSTICS + ISOLATED TEST WALLET.
// No purchase/auth handlers are replaced. No request bodies, cookies,
// receipt data, tokens, user IDs, or server responses are captured.
static EMTestWallet gTestWallet;
static NSString *gLastDiagnostic = @"Bereit – nur lokale Testwerte";

static BOOL EMIsKnownHandler(NSString *name) {
    static NSSet<NSString *> *known = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        known = [NSSet setWithArray:@[
            @"setAppUserid", @"setProductPrices", @"buyProduct",
            @"logout", @"deleteUser", @"watchVideo"
        ]];
    });
    return [known containsObject:name];
}

static NSString *EMSafeHostDescription(NSURL *url) {
    if (url == nil) return @"keine URL";
    NSString *host = url.host.lowercaseString ?: @"unbekannter Host";
    if ([host isEqualToString:@"energymanager.trophyapi.com"]) {
        // Only a fixed allowlist of public API path labels is shown.
        NSString *path = url.path ?: @"";
        if ([path isEqualToString:@"/api/payments/app.products.php"] ||
            [path isEqualToString:@"/api/payments/ios/callback.php"]) {
            return [NSString stringWithFormat:@"Host: %@, Pfad: %@", host, path];
        }
    }
    return [NSString stringWithFormat:@"Host: %@ (Pfad/Query verborgen)", host];
}

@interface EMDiagnosticsUI : NSObject
@property(nonatomic, strong) UIButton *bubble;
@property(nonatomic, strong) UIView *panel;
@property(nonatomic, strong) UILabel *status;
@property(nonatomic, strong) UILabel *lastEvent;
+ (instancetype)shared;
- (void)installIfPossible;
- (void)updateDiagnostic:(NSString *)safeMessage;
@end

@implementation EMDiagnosticsUI

+ (instancetype)shared {
    static EMDiagnosticsUI *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [[self alloc] init]; });
    return instance;
}

- (UIWindow *)frontWindow {
    UIApplication *app = [UIApplication sharedApplication];
    for (UIScene *scene in app.connectedScenes) {
        if (![scene isKindOfClass:[UIWindowScene class]] ||
            scene.activationState != UISceneActivationStateForegroundActive) continue;
        UIWindowScene *windowScene = (UIWindowScene *)scene;
        for (UIWindow *window in windowScene.windows) {
            if (window.isKeyWindow && window.rootViewController != nil) return window;
        }
    }
    for (UIWindow *window in app.windows) {
        if (window.isKeyWindow && window.rootViewController != nil) return window;
    }
    return nil;
}

- (UILabel *)labelWithFrame:(CGRect)frame text:(NSString *)text size:(CGFloat)fontSize {
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.text = text;
    label.font = [UIFont systemFontOfSize:fontSize];
    label.textColor = [UIColor whiteColor];
    label.numberOfLines = 0;
    return label;
}

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    (void)notification;
    [self installIfPossible];
}

- (void)installIfPossible {
    if (self.bubble.superview != nil) return;
    UIWindow *window = [self frontWindow];
    if (window == nil) return;

    CGFloat screenW = CGRectGetWidth(window.bounds);
    CGFloat panelW = MIN(screenW - 24.0, 330.0);
    CGFloat centerY = CGRectGetHeight(window.bounds) * 0.48;

    UIButton *bubble = [UIButton buttonWithType:UIButtonTypeSystem];
    bubble.frame = CGRectMake(MAX(8.0, screenW - 72.0), centerY, 54.0, 54.0);
    bubble.backgroundColor = [UIColor colorWithRed:0.10 green:0.38 blue:0.85 alpha:0.96];
    bubble.layer.cornerRadius = 27.0;
    bubble.layer.borderColor = [UIColor whiteColor].CGColor;
    bubble.layer.borderWidth = 1.0;
    [bubble setTitle:@"EM" forState:UIControlStateNormal];
    [bubble setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    bubble.titleLabel.font = [UIFont boldSystemFontOfSize:16.0];
    [bubble addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragBubble:)];
    [bubble addGestureRecognizer:pan];
    bubble.accessibilityLabel = @"Energy Manager lokale Diagnosetests";
    [window addSubview:bubble];
    self.bubble = bubble;

    UIView *panel = [[UIView alloc] initWithFrame:CGRectMake((screenW-panelW)/2.0, 90.0, panelW, 410.0)];
    panel.backgroundColor = [UIColor colorWithWhite:0.08 alpha:0.96];
    panel.layer.cornerRadius = 16.0;
    panel.layer.borderWidth = 1.0;
    panel.layer.borderColor = [UIColor colorWithWhite:0.45 alpha:0.85].CGColor;
    panel.hidden = YES;
    panel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;

    UILabel *title = [self labelWithFrame:CGRectMake(16, 8, panelW-32, 48)
                                      text:@"EM Diagnose · NUR LOKAL\nKeine Spiel-/Serveränderung" size:15];
    title.font = [UIFont boldSystemFontOfSize:15.0];
    [panel addSubview:title];

    NSArray<NSString *> *names = @[@"Infinite Money (Test)", @"Infinite Stars (Test)", @"Free Shopping (Test)"];
    for (NSInteger index = 0; index < (NSInteger)names.count; index++) {
        CGFloat y = 64.0 + (CGFloat)index * 43.0;
        UILabel *name = [self labelWithFrame:CGRectMake(16, y, panelW-97, 34) text:names[(NSUInteger)index] size:14];
        [panel addSubview:name];
        UISwitch *control = [[UISwitch alloc] initWithFrame:CGRectMake(panelW-70, y+2, 55, 31)];
        control.tag = index+1;
        [control addTarget:self action:@selector(testSwitchChanged:) forControlEvents:UIControlEventValueChanged];
        [panel addSubview:control];
    }

    UIButton *buy = [UIButton buttonWithType:UIButtonTypeSystem];
    buy.frame = CGRectMake(12, 203, (panelW-36)/2.0, 36);
    [buy setTitle:@"Testkauf 100" forState:UIControlStateNormal];
    [buy setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    buy.backgroundColor = [UIColor colorWithRed:0.15 green:0.40 blue:0.65 alpha:1];
    buy.layer.cornerRadius = 8;
    [buy addTarget:self action:@selector(testPurchase) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:buy];

    UIButton *reset = [UIButton buttonWithType:UIButtonTypeSystem];
    reset.frame = CGRectMake(12, 245, panelW-24, 36);
    [reset setTitle:@"Testwerte Reset" forState:UIControlStateNormal];
    [reset setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    reset.backgroundColor = [UIColor colorWithWhite:0.28 alpha:1];
    reset.layer.cornerRadius = 8;
    [reset addTarget:self action:@selector(resetValues) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:reset];

    UIButton *spendStars = [UIButton buttonWithType:UIButtonTypeSystem];
    spendStars.frame = CGRectMake(24+(panelW-36)/2.0, 203, (panelW-36)/2.0, 36);
    [spendStars setTitle:@"Test-Sterne -10" forState:UIControlStateNormal];
    [spendStars setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    spendStars.backgroundColor = [UIColor colorWithRed:0.36 green:0.31 blue:0.65 alpha:1];
    spendStars.layer.cornerRadius = 8;
    [spendStars addTarget:self action:@selector(testSpendStars) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:spendStars];

    UILabel *status = [self labelWithFrame:CGRectMake(16, 291, panelW-32, 51) text:@"" size:13];
    status.accessibilityIdentifier = @"emdiagnostics.localwallet";
    [panel addSubview:status];
    self.status = status;

    UILabel *lastEvent = [self labelWithFrame:CGRectMake(16, 346, panelW-32, 59) text:@"" size:11];
    lastEvent.textColor = [UIColor colorWithWhite:0.77 alpha:1];
    [panel addSubview:lastEvent];
    self.lastEvent = lastEvent;

    [window addSubview:panel];
    self.panel = panel;
    [self updateLabels];
}

- (void)updateLabels {
    self.status.text = [NSString stringWithFormat:@"Test-Geld: %lld   Test-Sterne: %lld\nSimulierte Käufe: %u",
        (long long)EMWalletVisibleMoney(&gTestWallet),
        (long long)EMWalletVisibleStars(&gTestWallet),
        (unsigned int)gTestWallet.testPurchases];
    self.lastEvent.text = [NSString stringWithFormat:@"Diagnose: %@", gLastDiagnostic];
}

- (void)updateDiagnostic:(NSString *)safeMessage {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self updateDiagnostic:safeMessage]; });
        return;
    }
    gLastDiagnostic = [safeMessage copy] ?: @"Keine Ereignisse";
    [self updateLabels];
}

- (void)togglePanel { self.panel.hidden = !self.panel.hidden; [self updateLabels]; }

- (void)dragBubble:(UIPanGestureRecognizer *)gesture {
    UIView *parent = self.bubble.superview;
    if (parent == nil) return;
    CGPoint t = [gesture translationInView:parent];
    CGPoint center = self.bubble.center;
    CGFloat half = CGRectGetWidth(self.bubble.bounds)/2.0;
    center.x = MAX(half, MIN(CGRectGetWidth(parent.bounds)-half, center.x+t.x));
    center.y = MAX(half, MIN(CGRectGetHeight(parent.bounds)-half, center.y+t.y));
    self.bubble.center = center;
    [gesture setTranslation:CGPointZero inView:parent];
}

- (void)testSwitchChanged:(UISwitch *)control {
    if (control.tag == 1) gTestWallet.infiniteMoney = control.isOn;
    if (control.tag == 2) gTestWallet.infiniteStars = control.isOn;
    if (control.tag == 3) gTestWallet.freeShopping = control.isOn;
    [self updateLabels];
}

- (void)testPurchase {
    BOOL succeeded = EMWalletPurchaseTestItem(&gTestWallet, 100);
    [self updateDiagnostic:succeeded ? @"Lokaler Testkauf OK – keine StoreKit-Anfrage" : @"Lokaler Testkauf: zu wenig Testgeld"];
}

- (void)testSpendStars {
    BOOL succeeded = EMWalletSpendTestStars(&gTestWallet, 10);
    [self updateDiagnostic:succeeded ? @"10 Test-Sterne verbraucht (nur lokal)" : @"Zu wenig Test-Sterne"];
}

- (void)resetValues {
    EMWalletReset(&gTestWallet);
    for (UIView *child in self.panel.subviews) {
        if ([child isKindOfClass:[UISwitch class]]) [(UISwitch *)child setOn:NO animated:YES];
    }
    [self updateDiagnostic:@"Lokale Testwerte zurückgesetzt"];
}
@end

// Only metadata of known WebView handler registrations is recorded.
// The original invocation is always called unmodified.
@interface WKUserContentController (EMDiagnostics)
- (void)emdiag_addScriptMessageHandler:(id<WKScriptMessageHandler>)handler name:(NSString *)name;
@end
@implementation WKUserContentController (EMDiagnostics)
- (void)emdiag_addScriptMessageHandler:(id<WKScriptMessageHandler>)handler name:(NSString *)name {
    [self emdiag_addScriptMessageHandler:handler name:name];
    if (EMIsKnownHandler(name)) {
        [[EMDiagnosticsUI shared] updateDiagnostic:[NSString stringWithFormat:@"WebView-Handler registriert: %@", name]];
    }
}
@end

// Never reads URL query strings, POST data, headers, cookies, receipts, or responses.
@interface WKWebView (EMDiagnostics)
- (WKNavigation *)emdiag_loadRequest:(NSURLRequest *)request;
@end
@implementation WKWebView (EMDiagnostics)
- (WKNavigation *)emdiag_loadRequest:(NSURLRequest *)request {
    [[EMDiagnosticsUI shared] updateDiagnostic:EMSafeHostDescription(request.URL)];
    return [self emdiag_loadRequest:request];
}
@end

static void EMSwap(Class cls, SEL original, SEL replacement) {
    Method old = class_getInstanceMethod(cls, original);
    Method newMethod = class_getInstanceMethod(cls, replacement);
    if (old != NULL && newMethod != NULL) method_exchangeImplementations(old, newMethod);
}

__attribute__((constructor)) static void EMReadOnlyDiagnosticsInit(void) {
    @autoreleasepool {
        // Double guard: the Theos plist additionally limits injection to this app.
        NSString *bundleID = [[NSBundle mainBundle] bundleIdentifier];
        if (![bundleID isEqualToString:@"com.trophygames.energymanager"]) return;
        EMWalletReset(&gTestWallet);
        EMSwap([WKUserContentController class], @selector(addScriptMessageHandler:name:),
               @selector(emdiag_addScriptMessageHandler:name:));
        EMSwap([WKWebView class], @selector(loadRequest:), @selector(emdiag_loadRequest:));
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] addObserver:[EMDiagnosticsUI shared]
                selector:@selector(applicationDidBecomeActive:)
                name:UIApplicationDidBecomeActiveNotification object:nil];
            [[EMDiagnosticsUI shared] installIfPossible];
        });
    }
}
