#import <UIKit/UIKit.h>
%config(generator=internal);
%hook UIViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    NSLog(@"[UbuntuDemo] View appeared: %@", NSStringFromClass([self class]));
}
%end
